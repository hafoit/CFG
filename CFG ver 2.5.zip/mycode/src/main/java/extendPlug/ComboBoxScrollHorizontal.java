package extendPlug;

import java.util.Vector;

import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JPopupMenu;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;


@SuppressWarnings("serial")
public class ComboBoxScrollHorizontal<E> extends JComboBox<E>{

	public ComboBoxScrollHorizontal(E[] args) {
		super(args);
		ajustaScrollBar(this);
	}

	public ComboBoxScrollHorizontal(ComboBoxModel<E> arg) {
		super(arg);
		ajustaScrollBar(this);
	}
	

	public ComboBoxScrollHorizontal(Vector<E> args) {
		super(args);
		ajustaScrollBar(this);
	}

	public ComboBoxScrollHorizontal() {
		super();
		ajustaScrollBar(this);
	}
	
	private void ajustaScrollBar(JComboBox<E> box) {
			Object comp = box.getUI().getAccessibleChild(box, 0);
	        if (comp instanceof JPopupMenu) {
	            JPopupMenu popup = (JPopupMenu) comp;
	            JScrollPane scrollPane = (JScrollPane) popup.getComponent(0);
	            scrollPane.setHorizontalScrollBar(new JScrollBar(JScrollBar.HORIZONTAL));
	            scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	        }
	}

}