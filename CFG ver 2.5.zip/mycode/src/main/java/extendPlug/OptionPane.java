package extendPlug;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


@SuppressWarnings("serial")
public class OptionPane extends JFrame {
	public int option;
	public OptionPane() {
		JPanel panel = new JPanel();

		Object[] options= {"Auto","Manual"};
		int result = JOptionPane.showOptionDialog(null, panel, "Choose traverse mode",
                JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE,
                null, options, null);
		
		if (result == JOptionPane.YES_OPTION){
            option=1;
        }
		else option=2;

		
	}
	

	
}
