package extendPlug;

import java.util.List;
import javax.swing.JTextArea;
import org.jgrapht.GraphPath;
import org.jgrapht.graph.DefaultEdge;

import Algorithm.HelloJGraphT;

public class ThreadFindPath implements Runnable {
	private int start;
	private int end;
	private JTextArea textArea;
	public ThreadFindPath(int start, int end, JTextArea textArea) {
		this.start=start;
		this.end=end;
		this.textArea=textArea;
	}
	public void run() {
		List<GraphPath<Integer, DefaultEdge>> v=HelloJGraphT.findPath(start,end);
		StringBuilder title=new StringBuilder("RECOMMENDED PATHS: \n");
        for (int i=0;i<v.size();i++) {
        	List<Integer>path =v.get(i).getVertexList();
        	for (int j=0;j<path.size()-1;j++)
        		title.append(path.get(j)+"->");
        title.append(path.get(path.size()-1)+"\n");
        }
        textArea.setText(title.toString());
    }

}
