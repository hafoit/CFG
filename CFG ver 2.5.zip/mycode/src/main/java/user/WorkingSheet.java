package user;

import java.awt.EventQueue;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JTextArea;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.text.DefaultCaret;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import org.jgrapht.GraphPath;
import org.jgrapht.ext.JGraphXAdapter;
import org.jgrapht.graph.DefaultEdge;

import com.mxgraph.util.mxCellRenderer;

import Algorithm.HelloJGraphT;
import extendPlug.ComboBoxScrollHorizontal;
import extendPlug.MyLabel;
import extendPlug.OptionPane;
import extendPlug.ThreadFindPath;

import java.awt.Font;
import java.awt.SystemColor;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JScrollPane;

public class WorkingSheet {
	static JFrame frame;
	public static File outputfile = new File("temp.jpg");
	public static  JTextField textField;
	public static JTextField textField_1;
    public static HelloJGraphT graph;
    public static int vertexId = 0;
	public static List<Integer> listPoint = new ArrayList<Integer>();
	public static MyLabel scrollLabel;
	private static JFrame f = new JFrame();
	/**
	 * Launch the application.
	 */
	public static void main() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					@SuppressWarnings("unused")
					WorkingSheet window = new WorkingSheet();
					WorkingSheet.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws IOException 
	 */
	public WorkingSheet() throws IOException {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws IOException 
	 */
	public static void initialize() throws IOException {
		frame = new JFrame();
		frame.setBackground(Color.WHITE);
		
		frame.setBounds(0,0,1366,768);
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel.setBackground(new Color(255, 255, 255));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new CompoundBorder());
		panel_1.setBackground(Color.LIGHT_GRAY);
		Border border = BorderFactory.createLineBorder(Color.BLACK);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.GRAY);
		
		
		
		JButton btnBack = new JButton("");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		btnBack.setIcon(new ImageIcon("icons8-left-arrow-50.png"));
		btnBack.setBackground(Color.WHITE);
		btnBack.setBackground(SystemColor.inactiveCaption);
		btnBack.setOpaque(false);
		btnBack.setContentAreaFilled(false);
		btnBack.setBorderPainted(false);
		
		JButton btnNext = new JButton("");
		btnNext.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		btnNext.setForeground(SystemColor.desktop);
		btnNext.setIcon(new ImageIcon("icons8-right-arrow-50.png"));
		btnNext.setBackground(SystemColor.inactiveCaption);
		btnNext.setOpaque(false);
		btnNext.setContentAreaFilled(false);
		btnNext.setBorderPainted(false);
		GroupLayout gl_panel_2 = new GroupLayout(panel_2);
		gl_panel_2.setHorizontalGroup(
			gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup()
					.addGap(103)
					.addComponent(btnBack, GroupLayout.DEFAULT_SIZE, 363, Short.MAX_VALUE)
					.addGap(89)
					.addComponent(btnNext, GroupLayout.DEFAULT_SIZE, 364, Short.MAX_VALUE)
					.addGap(104))
		);
		gl_panel_2.setVerticalGroup(
			gl_panel_2.createParallelGroup(Alignment.TRAILING)
				.addComponent(btnBack, GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE)
				.addComponent(btnNext, GroupLayout.DEFAULT_SIZE, 57, Short.MAX_VALUE)
		);
		panel_2.setLayout(gl_panel_2);
		
		textField = new JTextField();
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				if(!Character.isDigit(e.getKeyChar())) {
					e.consume();
				}
			}
		});
		textField.setColumns(10);
		
		//Home button
		
		JButton btnNewButton_1_1_1 = new JButton("Home");
		btnNewButton_1_1_1.setBackground(Color.WHITE);
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
		@SuppressWarnings("static-access")
		public void actionPerformed(ActionEvent e) {
			try {
				frame.dispose();
				intro window1 = new intro();							
				window1.frame.setVisible(true);
			} catch (Exception ee) {
				ee.printStackTrace();
			}
		}
		});
		
		JLabel lblNewLabel_2_1 = new JLabel("End vertex");
	
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1.setIconTextGap(30);
		
		JLabel lblNewLabel_3 = new JLabel("PATH  BETWEEN  TWO  VERTEXES");
		lblNewLabel_3.setForeground(Color.DARK_GRAY);
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setIconTextGap(60);
		 
		
		textField_1 = new JTextField();
		textField_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				if(!Character.isDigit(e.getKeyChar())) {
					e.consume();
				}
			}
		});
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Begin vertex");
		lblNewLabel_2.setIconTextGap(30);
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		
		scrollLabel = new MyLabel(ImageIO.read(new File("graph.png")));
		scrollLabel.setBackground(Color.WHITE);
		
		
		JButton btnNewButton_1_1 = new JButton("Find");
		btnNewButton_1_1.setBackground(Color.WHITE);
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 256, GroupLayout.PREFERRED_SIZE)
					.addGap(0)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(scrollLabel, GroupLayout.DEFAULT_SIZE, 1023, Short.MAX_VALUE)
						.addComponent(panel_2, GroupLayout.DEFAULT_SIZE, 1023, Short.MAX_VALUE)))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 696, Short.MAX_VALUE)
				.addGroup(gl_panel.createSequentialGroup()
					.addComponent(scrollLabel, GroupLayout.DEFAULT_SIZE, 633, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panel_2, GroupLayout.PREFERRED_SIZE, 57, GroupLayout.PREFERRED_SIZE))
		);
		
		JScrollPane scrollPane = new JScrollPane();
		
		JTextArea textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		textArea.setEditable(false);
		textArea.setBorder(BorderFactory.createCompoundBorder(border, 
		      BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		
		JScrollPane scrollPane_1 = new JScrollPane();
		
		JTextArea pathChoosenText = new JTextArea();
		scrollPane_1.setViewportView(pathChoosenText);
		pathChoosenText.setFont(new Font("Monospaced", Font.PLAIN, 14));
		pathChoosenText.setEditable(false);
		pathChoosenText.setBackground(Color.WHITE);
		DefaultCaret caret = (DefaultCaret)pathChoosenText.getCaret();
		caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addComponent(lblNewLabel_3, GroupLayout.PREFERRED_SIZE, 256, GroupLayout.PREFERRED_SIZE)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(24)
					.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE)
					.addGap(42)
					.addComponent(lblNewLabel_2_1, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE))
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(24)
					.addComponent(textField, GroupLayout.PREFERRED_SIZE, 81, GroupLayout.PREFERRED_SIZE)
					.addGap(50)
					.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE))
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(87)
					.addComponent(btnNewButton_1_1, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE))
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(21)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 214, GroupLayout.PREFERRED_SIZE))
				.addComponent(scrollPane_1, GroupLayout.PREFERRED_SIZE, 256, GroupLayout.PREFERRED_SIZE)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(87)
					.addComponent(btnNewButton_1_1_1, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(30)
					.addComponent(lblNewLabel_3, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
					.addGap(4)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_2_1, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
					.addGap(10)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE))
					.addGap(11)
					.addComponent(btnNewButton_1_1)
					.addGap(11)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 392, Short.MAX_VALUE)
					.addGap(30)
					.addComponent(scrollPane_1, GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
					.addGap(12)
					.addComponent(btnNewButton_1_1_1)
					.addGap(11))
		);
		panel_1.setLayout(gl_panel_1);
		panel.setLayout(gl_panel);
		
		
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HelloJGraphT.focusList.clear();
				f.dispose();

				btnBack.setEnabled(true);
				btnNext.setEnabled(true);
				String start=textField.getText();
				String end=textField_1.getText();
				if(start.length() == 0 || end.length() == 0) {
					btnBack.setEnabled(false);
					btnNext.setEnabled(false);
					JOptionPane.showMessageDialog(null, "Please enter Begin Vertex and End Vertex!", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				int a = Integer.parseUnsignedInt(start);
				int b= Integer.parseUnsignedInt(end);
				
				if(!(HelloJGraphT.dg.containsVertex(a)&&HelloJGraphT.dg.containsVertex(b))) {
					textArea.setText("");
					listPoint.clear();
					vertexId = a;
					btnBack.setEnabled(false);
					btnNext.setEnabled(false);
					pathChoosenText.setText("");
					JOptionPane.showMessageDialog(null,"Invalid vertexes!","Error",JOptionPane.ERROR_MESSAGE);
					return;
				};
				
				if(a == b) {
					JGraphXAdapter<Integer, DefaultEdge> graphAdapter=HelloJGraphT.getGraphX(HelloJGraphT.dg);
					List<Integer> subList = new ArrayList<>();
					subList.add(a);
					try {
						HelloJGraphT.givenAdaptedGraph_whenWriteBufferedImage_thenFileShouldExist(graphAdapter,subList);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					btnBack.setEnabled(false);
					btnNext.setEnabled(false);
        			HelloJGraphT.focusList.add(HelloJGraphT.focusVertex);
        			BufferedImage image = mxCellRenderer.createBufferedImage(graphAdapter, null, 2, Color.WHITE, true, null);
        			scrollLabel.setImage(image);
        			JOptionPane.showMessageDialog(null, "Finished!", null, JOptionPane.PLAIN_MESSAGE);
        			return;
				}
				
				OptionPane op=new OptionPane();
				op.dispose();
				if (op.option==2) {
				try {
					listPoint.clear();	
					scrollLabel.setImage(ImageIO.read(new File("graph.png")));
					vertexId = a;
					JGraphXAdapter<Integer, DefaultEdge> graphAdapter=HelloJGraphT.getGraphX(HelloJGraphT.dg);
					ThreadFindPath th=new ThreadFindPath(a,b,textArea);
					Thread thread = new Thread(th);
					thread.start();
			        if (btnNext.getActionListeners().length>=1) {
			        	for( ActionListener al : btnNext.getActionListeners() ) {
			        		btnNext.removeActionListener( al );
			        	}
			        }
			        if (btnBack.getActionListeners().length>=1) {
			        	for( ActionListener al : btnBack.getActionListeners() ) {
			        		btnBack.removeActionListener( al );
			        	}
			        }
			        listPoint.add(a);
			        HelloJGraphT.givenAdaptedGraph_whenWriteBufferedImage_thenFileShouldExist(graphAdapter,listPoint);
			        HelloJGraphT.focusList.add(HelloJGraphT.focusVertex);
					BufferedImage image = mxCellRenderer.createBufferedImage(graphAdapter, null, 2, Color.WHITE, true, null);
					scrollLabel.setImage(image);
			        pathChoosenText.setText("");
					StringBuilder pathChoose = new StringBuilder("PATH LOG");
			        ArrayList<JFrame> frameList=new ArrayList<JFrame>();
			        btnNext.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							if (frameList.size()>0)
								for (JFrame frame:frameList)
									frame.dispose();
							f=new JFrame();
							f.setLocationRelativeTo(null);
							f.setTitle("Choose the next vertex");
							ArrayList<Integer> availableVertex=new ArrayList<Integer>();
							f.setSize(300, 70);
							for (int i=1;i<=HelloJGraphT.numVertex;i++) {
								if (HelloJGraphT.dg.containsEdge(vertexId,i))
									availableVertex.add(i);
							}
							if (availableVertex.size()==0) {
								JOptionPane.showMessageDialog(null, "Can not continue!", null, JOptionPane.PLAIN_MESSAGE);
								return;
							}
							Integer[] ver=new Integer[availableVertex.size()];
							availableVertex.toArray(ver);
							JComboBox<Integer> selectBox=new JComboBox<Integer>(ver);
							f.getContentPane().add(selectBox);
							f.setVisible(true);
							frameList.add(f);
							selectBox.addActionListener(new ActionListener() {
									public void actionPerformed(ActionEvent e) {
										vertexId=(Integer) selectBox.getSelectedItem();
										if(vertexId==b ||HelloJGraphT.findPath(vertexId, b).size() > 0 ) {
										f.dispose();
										listPoint.add(vertexId);
										int i = listPoint.size() - 2;
										pathChoose.append("\n"+(i+1)+") "+listPoint.get(i).toString() + "->"+listPoint.get(i+1).toString());
										pathChoosenText.setText(pathChoose.toString());
										try {
											HelloJGraphT.givenAdaptedGraph_whenWriteBufferedImage_thenFileShouldExist(graphAdapter,listPoint);
											HelloJGraphT.focusList.add(HelloJGraphT.focusVertex);
											BufferedImage image = mxCellRenderer.createBufferedImage(graphAdapter, null, 2, Color.WHITE, true, null);
											scrollLabel.setImage(image);
										} catch (IOException e1) {
											// TODO Auto-generated catch block
											e1.printStackTrace();
										}
										if (vertexId==b) {
											JOptionPane.showMessageDialog(null, "Finished!", null, JOptionPane.PLAIN_MESSAGE);
										}
										}
										else{
											JOptionPane.showMessageDialog(null, "Can't go to the end from vertex "+vertexId, "Error", JOptionPane.ERROR_MESSAGE);
											
											vertexId=listPoint.get(listPoint.size()-1);
										}
									}
								});
							
							
							
							
				        }
					});
			        btnBack.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {
			        		int last = pathChoose.lastIndexOf("\n");
			        		if (last >= 0) pathChoose.delete(last, pathChoose.length());
			        		pathChoosenText.setText(pathChoose.toString());
			        		if (listPoint.size()>1) {
			        			listPoint.remove(listPoint.size()-1);
			        			try {
									HelloJGraphT.givenAdaptedGraph_whenWriteBufferedImage_thenFileShouldExist(graphAdapter, listPoint);
									HelloJGraphT.focusList.remove(HelloJGraphT.focusList.size()-1);
								} catch (IOException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
			        		}
			        		vertexId=listPoint.get(listPoint.size()-1);
		        			BufferedImage image = mxCellRenderer.createBufferedImage(graphAdapter, null, 2, Color.WHITE, true, null);
							scrollLabel.setImage(image);
		        			
			        	}
			        });

				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
				}
				if (op.option==1) {
					try {
						pathChoosenText.setText("");				
						scrollLabel.setImage(ImageIO.read(new File("graph.png")));
						vertexId=0;
						JGraphXAdapter<Integer, DefaultEdge> graphAdapter=HelloJGraphT.getGraphX(HelloJGraphT.dg);
						
						List<GraphPath<Integer, DefaultEdge>> paths=HelloJGraphT.findPath(a,b);
				    	// Show path options for user to choose
						f=new JFrame();
						f.setTitle("Choose the path to go from "+a+" to "+b);
						f.setSize(400, 70);
				    	ArrayList<String> tempways=new ArrayList<String>();
				    	String[] ways=new String[paths.size()];
				    	for (GraphPath<Integer, DefaultEdge> path:paths) {
				    		List<Integer> v=path.getVertexList();
				    		StringBuilder temp=new StringBuilder();
				        	for (int i=0;i<v.size()-1;i++) {
				        		temp.append(v.get(i)+"->");
				        	}
				        	temp.append(v.get(v.size()-1));
				        	tempways.add(temp.toString());
				        }
				    	tempways.toArray(ways);
				    	ComboBoxScrollHorizontal<String> selectPath=new ComboBoxScrollHorizontal<String>(ways);
				    	f.getContentPane().add(selectPath);
				    	f.setLocationRelativeTo(null);
						f.setVisible(true);
						selectPath.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								f.dispose();
								int pathId= selectPath.getSelectedIndex();
								GraphPath<Integer, DefaultEdge> path=paths.get(pathId);
								List<Integer> v=path.getVertexList();
								StringBuilder title=new StringBuilder("Choosen path: ");
						        for (int i=0;i<v.size()-1;i++) {
						        	title.append(v.get(i)+"->");
						        }
						        title.append(v.get(v.size()-1));
				
						        StringBuilder pathTraversed=new StringBuilder(" PATH LOG: ");
						        textArea.setText(pathTraversed.toString());
						        
						        if (btnNext.getActionListeners().length>=1) {
						        	for( ActionListener al : btnNext.getActionListeners() ) {
						        		btnNext.removeActionListener( al );
						        	}
						        }
						        if (btnBack.getActionListeners().length>=1) {
						        	for( ActionListener al : btnBack.getActionListeners() ) {
						        		btnBack.removeActionListener( al );
						        	}
						        }
						        List<Integer> subList=v.subList(0, vertexId+1);
				        		try {
				        			HelloJGraphT.givenAdaptedGraph_whenWriteBufferedImage_thenFileShouldExist(graphAdapter,subList);
				        			BufferedImage image = mxCellRenderer.createBufferedImage(graphAdapter, null, 2, Color.WHITE, true, null);
				        			scrollLabel.setImage(image);
				        			
				        			
				        		} catch (IOException e1) {
				        			// TODO Auto-generated catch block
				        			e1.printStackTrace();
				        		}
						        btnNext.addActionListener(new ActionListener() {
									public void actionPerformed(ActionEvent e) {
										if (vertexId==v.size()-1) {
						        			JOptionPane.showMessageDialog(null, "Finished!", null, JOptionPane.PLAIN_MESSAGE);
						        			return;
						        		}
										// change the image in the frame
										
										if (vertexId>=0) {
											pathTraversed.append("\n  "+(vertexId+1)+") "+v.get(vertexId)+"->"+v.get(vertexId+1));
											textArea.setText(pathTraversed.toString());
										}
										if (vertexId==v.size()) return;
						        		List<Integer> subList=v.subList(0, vertexId+2);
						        		try {
						        			HelloJGraphT.givenAdaptedGraph_whenWriteBufferedImage_thenFileShouldExist(graphAdapter,subList);
						        			HelloJGraphT.focusList.add(HelloJGraphT.focusVertex);
						        			BufferedImage image = mxCellRenderer.createBufferedImage(graphAdapter, null, 2, Color.WHITE, true, null);
						        			scrollLabel.setImage(image);
						        			vertexId++;
						        			
						        		} catch (IOException e1) {
						        			// TODO Auto-generated catch block
						        			e1.printStackTrace();
						        		}
						        		if (vertexId==v.size()-1) {
						        			JOptionPane.showMessageDialog(null, "Finished!", null, JOptionPane.PLAIN_MESSAGE);
						        		}
							        }
								});
						        btnBack.addActionListener(new ActionListener() {
						        	public void actionPerformed(ActionEvent e) {
						        		int last = pathTraversed.lastIndexOf("\n");
						        		if (last >= 0) pathTraversed.delete(last, pathTraversed.length());
						        		textArea.setText(pathTraversed.toString());
						        		if(vertexId==0) return ;
						        		if(vertexId>=1) {
						        			vertexId-=1;
						        			HelloJGraphT.focusVertex = HelloJGraphT.focusList.get(vertexId);
						        			HelloJGraphT.focusList.remove(HelloJGraphT.focusList.get(vertexId));
						        			List<Integer> subList=v.subList(0, vertexId + 1);
							        		try {
							        			HelloJGraphT.givenAdaptedGraph_whenWriteBufferedImage_thenFileShouldExist(graphAdapter,subList);
							        			BufferedImage image = mxCellRenderer.createBufferedImage(graphAdapter, null, 2, Color.WHITE, true, null);
							        			scrollLabel.setImage(image);		
							        		} catch (IOException e1) {
							        			// TODO Auto-generated catch block
							        			e1.printStackTrace();
							        		}
						        		}
						        		return;
						        	}
						        });
							}
						});
						
						
						
					} catch (IOException e1) {
						
						e1.printStackTrace();
					}
				}
			}
		});
	}
}
