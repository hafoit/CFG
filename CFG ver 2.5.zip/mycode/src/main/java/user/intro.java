package user;
import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;

import Algorithm.HelloJGraphT;

import java.awt.SystemColor;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Component;

public class intro {
    static String image_path=null;
	public static JFrame frame;
	public static JTextField setFile;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					@SuppressWarnings("unused")
					intro window = new intro();
					intro.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public intro() {
		initialize();
	}
	public void initialize() {
		 try {
			UIManager.setLookAndFeel(
			            UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
				| UnsupportedLookAndFeelException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		frame = new JFrame();
		frame.setBackground(new Color(255, 255, 0));
		frame.getContentPane().setForeground(new Color(255, 255, 0));
		frame.setForeground(new Color(255, 255, 0));
		frame.getContentPane().setMaximumSize(new Dimension(2147483634, 2147483646));
		frame.getContentPane().setBackground(Color.DARK_GRAY);
		frame.setBounds(100, 100, 733, 449);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setResizable(false);
		JPanel panel = new JPanel();
		panel.setBounds(0, 221, 717, 191);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Enter your graph file path:");
		lblNewLabel.setBounds(67, 49, 155, 52);
		panel.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(SystemColor.infoText);
		
		setFile = new JTextField();
		setFile.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER) {
					String file= setFile.getText();		
					try {
						@SuppressWarnings("unused")
						HelloJGraphT graph= new HelloJGraphT(file);
						WorkingSheet.main();
						frame.dispose();
					} catch (IOException e1) {
						
						e1.printStackTrace();
					}
					
				}
			}
		});
		setFile.setBounds(228, 65, 304, 20);
		panel.add(setFile);
		setFile.setColumns(10);
		
		JButton buttonNext = new JButton("Next");
		buttonNext.setBackground(Color.WHITE);
		buttonNext.setBounds(212, 112, 85, 23);
		panel.add(buttonNext);
		
		JButton buttonCancel = new JButton("Cancel");
		buttonCancel.setBackground(Color.WHITE);
		buttonCancel.setBounds(407, 112, 92, 23);
		panel.add(buttonCancel);
		
		JButton selectFile = new JButton("Choose");
		selectFile.setBackground(Color.WHITE);
		selectFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String path=null;
				JFileChooser chooser=new JFileChooser();
				chooser.setCurrentDirectory(new File(System.getProperty("user.home")));
				FileNameExtensionFilter extension = new FileNameExtensionFilter(".txt","txt");
				chooser.addChoosableFileFilter(extension);
				int filestate =chooser.showSaveDialog(null);
				if(filestate==JFileChooser.APPROVE_OPTION) {
					File selectedImage= chooser.getSelectedFile();
					path=selectedImage.getAbsolutePath();
					setFile.setText(path);
					
				}
			}
		});
		selectFile.setBounds(554, 64, 87, 23);
		panel.add(selectFile);
		buttonCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result=JOptionPane.showConfirmDialog(null, "Are you sure ?","Confirm", JOptionPane.YES_NO_OPTION);
				if(result==JOptionPane.YES_OPTION) {
					System.exit(0);
				}
			}
		});
		buttonNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String file= setFile.getText();
				try {
					@SuppressWarnings("unused")
					HelloJGraphT graph= new HelloJGraphT(file);
					WorkingSheet.main();
					frame.dispose();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				
			}
		});
		
		JPanel panel_1 = new JPanel();
		panel_1.setAutoscrolls(true);
		panel_1.setAlignmentY(Component.TOP_ALIGNMENT);
		panel_1.setBounds(0, 0, 717, 221);
		panel_1.setBackground(Color.LIGHT_GRAY);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Vu Quang Truong, Nguyen Trong Bang, Vo Thuc Khanh Huyen, Trinh Hong Phuong, Nguyen Quoc Hao, Nguyen Ngoc Bao\r\n");
		lblNewLabel_1.setAlignmentY(0.25f);
		lblNewLabel_1.setAlignmentX(0.25f);
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 12));
		lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_1.setIconTextGap(40);
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setBackground(Color.DARK_GRAY);
		lblNewLabel_1.setBounds(25, 152, 667, 20);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("CONTROL FLOW GRAPH");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("CONTROL FLOW GRAPH", Font.BOLD, 25));
		lblNewLabel_2.setBounds(205, 57, 304, 33);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("AUTHORS");
		lblNewLabel_3.setForeground(Color.DARK_GRAY);
		lblNewLabel_3.setFont(new Font("Arial", Font.BOLD, 18));
		lblNewLabel_3.setBounds(315, 115, 95, 37);
		panel_1.add(lblNewLabel_3);
	}
}
