package Algorithm;


import java.awt.Color;
import java.awt.image.BufferedImage;

import javax.swing.*;

import javax.imageio.ImageIO;

import org.jgrapht.GraphPath;
import org.jgrapht.alg.shortestpath.*;
import org.jgrapht.ext.JGraphXAdapter;
import org.jgrapht.graph.*;
import com.mxgraph.layout.*;
import com.mxgraph.layout.hierarchical.mxHierarchicalLayout;
import com.mxgraph.model.*;
import com.mxgraph.util.*;
import com.mxgraph.view.mxStylesheet;

import java.io.*;
import java.util.*;

public class HelloJGraphT {
	public static Object focusVertex;
	public static List<Object> focusList = new ArrayList<>();
	public static DefaultDirectedGraph<Integer, DefaultEdge> dg;
	static File imgFile;
	static mxIGraphLayout layout;
	static int size = 0;
	public static int numVertex=0;
	static int pathId;
	public static JGraphXAdapter<Integer, DefaultEdge> getGraphX(DefaultDirectedGraph<Integer, DefaultEdge> dg){
		JGraphXAdapter<Integer, DefaultEdge> graphAdapter = new JGraphXAdapter<Integer, DefaultEdge>(dg);
		
		return graphAdapter;
	}
	public HelloJGraphT(String file) throws IOException {
		dg = new DefaultDirectedGraph<>(DefaultEdge.class);
        // read text file to create JgraphT model
        try {
            File myObj = new File(file);
            Scanner myReader = new Scanner(myObj);
            LineNumberReader lineNumberReader = new LineNumberReader(new FileReader(myObj));
            lineNumberReader.skip(Long.MAX_VALUE);
            numVertex = lineNumberReader.getLineNumber();
            lineNumberReader.close();
            ArrayList<Integer> vertex=new ArrayList<Integer>();
            for (int i=1;i<=numVertex;i++) {
            	size ++;
            	vertex.add(i);
            	dg.addVertex(i);
            }
            while (myReader.hasNextLine()) {
              String data = myReader.nextLine();
              String[] v=data.split("->");
              int i=Integer.parseInt(v[0]);
              if (v.length>1) {
            	  for (int j=1;j<v.length;j++) {
            		  dg.addEdge(i, Integer.parseInt(v[j]));
            	  }
              }
            }
            myReader.close();
          } catch (FileNotFoundException e) {
        	  JOptionPane.showMessageDialog(null,"The path isn't exist!");
            e.printStackTrace();
          }
        List<Integer>init= new ArrayList<Integer>();
        
        JGraphXAdapter<Integer, DefaultEdge>ga=getGraphX(dg);
        layout = new mxHierarchicalLayout(ga);
        layout.execute(ga.getDefaultParent());
        givenAdaptedGraph_whenWriteBufferedImage_thenFileShouldExist(ga,init);
        BufferedImage image = mxCellRenderer.createBufferedImage(ga, null, 2, Color.WHITE, true, null);
        imgFile = new File("graph.png");
        ImageIO.write(image, "PNG", imgFile);
	}
	
	@SuppressWarnings("deprecation")
	public static List<GraphPath<Integer, DefaultEdge>> findPath(int a, int b) {
		List<GraphPath<Integer, DefaultEdge>> paths=new ArrayList<GraphPath<Integer, DefaultEdge>>();
		KShortestPaths<Integer, DefaultEdge> pathInspector = new KShortestPaths<Integer, DefaultEdge>(dg,10, Integer.MAX_VALUE);
	    try {
		paths = pathInspector.getPaths(a,b);
	    } catch (NumberFormatException e){
	    	JOptionPane.showMessageDialog(null,"The values are invalid!");
	    }
    	    
        return paths;
	}

	
	public static void givenAdaptedGraph_whenWriteBufferedImage_thenFileShouldExist(JGraphXAdapter<Integer, DefaultEdge> graphAdapter,List<Integer> v) throws IOException {
    	// Mark checked vertexes and edges in list v
		layout.execute(graphAdapter.getDefaultParent());

        Object[] cells= graphAdapter.getChildCells(graphAdapter.getDefaultParent(),true,true);
        if(v.size() > 0) focusVertex = cells[v.get(v.size() - 1) - 1];
        else focusVertex = cells[0];
        
        //Initial status of graph 
        for (Object c : cells) {
            mxCell cell = (mxCell) c; //cast
            mxGeometry geometry = cell.getGeometry();
            if (cell.isVertex()) { //isVertex
                // Change vertex style
                geometry.setWidth(20);
                geometry.setHeight(20);
                cell.setStyle("UncheckedVertex");
                if (v.contains(Integer.parseInt(cell.getValue().toString()))) {
                	cell.setStyle("CheckedVertex");
                }
                if (c.equals(focusVertex)) {
                	cell.setStyle("FocusVertex");
                }
            }else { //is not a vertex
                cell.setStyle("UncheckedEdge");
            }
        }
        if (v.size()>1) {
        	Object[] edges=graphAdapter.getChildEdges(graphAdapter.getDefaultParent());
        	// Change checked edge style
        	for (int i=0;i<v.size()-1;i++) {
        		for (Object x:edges) {
        			mxCell e=(mxCell)x;
        			if (Integer.parseInt(e.getSource().getValue().toString())==v.get(i) && Integer.parseInt(e.getTarget().getValue().toString())==v.get(i+1) ) {
        				e.setStyle("CheckedEdge");
        				break;
        			}
        		}
        	}
        }
        //Create customized styles for edge and vertex (checked and unchecked)
        
        mxStylesheet stylesheet = graphAdapter.getStylesheet();
        
        Hashtable<String, Object> style = new Hashtable<String, Object>();
        style.put(mxConstants.STYLE_SHAPE, mxConstants.SHAPE_ELLIPSE);
        style.put(mxConstants.STYLE_OPACITY, 50);
        style.put(mxConstants.STYLE_FONTCOLOR, "#2f2f2f");
        style.put(mxConstants.STYLE_FILLCOLOR, "b8fcff");
        stylesheet.putCellStyle("UncheckedVertex", style);
        
        Hashtable<String, Object> style3 = new Hashtable<String, Object>();
        style3.put(mxConstants.STYLE_SHAPE, mxConstants.SHAPE_ELLIPSE);
        style3.put(mxConstants.STYLE_OPACITY, 50);
        style3.put(mxConstants.STYLE_FONTCOLOR, "#2f2f2f");
        style3.put(mxConstants.STYLE_FILLCOLOR, "e10600");
        style3.put(mxConstants.STYLE_STROKECOLOR, "e10600");
        stylesheet.putCellStyle("CheckedVertex", style3);
        
        Hashtable<String, Object> style1 = new Hashtable<String, Object>();
        style1.put(mxConstants.STYLE_FONTSIZE,0);
        style1.put(mxConstants.STYLE_STROKECOLOR, "139ffd");
        style1.put(mxConstants.STYLE_OPACITY, 50);
        stylesheet.putCellStyle("UncheckedEdge", style1);
        
        Hashtable<String, Object> style2 = new Hashtable<String, Object>();
        style2.put(mxConstants.STYLE_FONTSIZE,0);
        style2.put(mxConstants.STYLE_STROKECOLOR, "e10600");
        style2.put(mxConstants.STYLE_OPACITY, 50);
        stylesheet.putCellStyle("CheckedEdge", style2);
        
        Hashtable<String, Object> style4 = new Hashtable<String, Object>();
        style4.put(mxConstants.STYLE_SHAPE, mxConstants.SHAPE_ELLIPSE);
        style4.put(mxConstants.STYLE_OPACITY, 50);
        style4.put(mxConstants.STYLE_FONTCOLOR, "#2f2f2f");
        style4.put(mxConstants.STYLE_FILLCOLOR, "#FFC00E");
        stylesheet.putCellStyle("FocusVertex", style4);
    }
    
    public static boolean isNumeric(String str) { 
    	String s=str.trim();  
    	try {  
    	    Integer.parseInt(s);  
    	    return true;
    	} catch(NumberFormatException e){  
    	    return false;  
    	}  
    }
}
